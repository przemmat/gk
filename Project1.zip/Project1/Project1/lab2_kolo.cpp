#include <iostream>
#include <GL/glut.h>
#include <math.h>
using namespace std;


int x, y, r;

void glInit()
{

	glClearColor(0.5, 0.0, 0.5, 1.0);
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0, 300, 0, 300);
}

void setPixel(int x, int y)
{
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
}
///////// Wszystkie 3 wersje w komnaetarzu pod mainem
void myDisplay()

{
	int xp = 0, yp = r;
	int e1 = 0, e2 = 0, e = 0;
	while (xp <= yp)
	{
		setPixel(x + xp, y + yp);
		setPixel(yp + x, y - xp);
		setPixel(x - xp, y - yp);
		setPixel(x - yp, y + xp);
		setPixel(x + yp, y + xp);
		setPixel(x + xp, y - yp);
		setPixel(x - yp, y - xp);
		setPixel(x - xp, y + yp);
		e1 = e + 2 * xp + 1;
		e2 = e1 - 2 * yp + 1;
		xp++;
		if (e1 + e2 < 0)
		{
			e = e1;
		}
		else
		{
			yp = yp - 1;
			e = e2;
		}
	}
	glFlush();
}

int main(int argcp, char** argv)
{

	x = 150;
	y = 200;
	r = 90;
	glutInit(&argcp, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(300, 300);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Test OpenGL");
	glInit();
	glutDisplayFunc(myDisplay);
	glutMainLoop();
	return 0;
}

//
////}/*
//void myDisplay()
//{
//	int xp = 0, yp = r;
//	double e1 = 0, e2 = 0, e = 0;
//	while (xp <= yp)
//	{
//		setPixel(x + xp, y + yp);
//		setPixel(yp + x, y - xp);
//		setPixel(x - xp, y - yp);
//		setPixel(x - yp, y + xp);
//		setPixel(x + yp, y + xp);
//		setPixel(x + xp, y - yp);
//		setPixel(x - yp, y - xp);
//		setPixel(x - xp, y + yp);
//		e1 = e + 2 * xp + 1;
//		e2 = e1 - 2 * yp + 1;
//		xp++;
//		if (e1 + e2 < 0)
//		{
//			e = e1;
//		}
//		else
//		{
//			yp = yp - 1;
//			e = e2;
//		}
//	}
//	glFlush();
//}
//*/
/*void myDisplay()
{
	int xp = 0, yp;
	for (int i = 0; i < r; i++)
	{
		yp = sqrt(pow(r, 2) - pow((xp), 2));
		setPixel(x + xp, y + yp);
		setPixel(x + xp, y - yp);
		setPixel(x - xp, y + yp);
		setPixel(x - xp, y - yp);
		xp++;
	}
	glFlush();
}*/
/*
void myDisplay()
{
	int xp = 0, yp = 2137;
	while (xp < yp)
	{
		yp = sqrt(pow(r, 2) - pow((xp), 2));
		setPixel(x + xp, y + yp);
		setPixel(y + yp, x + xp);
		setPixel(x + xp, y - yp);
		setPixel(y + yp, x - xp);
		setPixel(x - xp, y + yp);
		setPixel(y - yp, x + xp);
		setPixel(x - xp, y - yp);
		setPixel(y - yp, x - xp);
		xp++;
	}
	glFlush();
}
*/