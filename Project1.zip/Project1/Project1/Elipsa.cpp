﻿
#include <iostream>
#include <cmath>
#include <ctime>
#include <GL/glut.h>
using namespace std;

float th = 0.0;
float trX = 0.0, trY = 0.0;
float angle = 0;
int rFlag = 0;
float x = 1.5f, y = 0.0f, z = 0 - 7.0f;
float xrot = 0,yrot=0,zrot=0;



void initGL() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Ustawienie koloru tła na czarny i nieprzezroczysty
	glClearDepth(1.0f);                   // Ustawienie głębi tła na najdalszą
	glEnable(GL_DEPTH_TEST);   // Włączenie testowania głębi dla ukrywania pikseli
	glDepthFunc(GL_LEQUAL);    // Ustawienie typu testowania głębi
	glShadeModel(GL_SMOOTH);   // Włączenie wygładzania
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);  // Włączenie korekcji perspektywy
}

static void Timer(int value)
{
	th += 0.5;
	glutPostRedisplay();
	// 100 milliseconds
	glutTimerFunc(20, Timer, 0);
}


void display() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Wyczyszczenie buforów kolorów i głębi
	glMatrixMode(GL_MODELVIEW);     // Operowanie na macierzy widoku modelu
	
	glLoadIdentity();                 // Zresetowanie macierzy widoku modelu
	// renderowanie kolorowego sześcianu składającego się z sześciu kwadratów w różnych kolorach 
	glTranslatef(x, y, z);  // Przesunięcie w prawo i wgłąb ekranu

	glBegin(GL_QUADS);                // rozpoczęcie rysowania sześciu kwadratów
	// Top face (y = 1.0f)
	// definiowanie wierzchołków przeciwnie do ruchu wskazówek zegara
	glColor3f(0.0f, 1.0f, 0.0f);     // Zielony
	glVertex3f(1.0f, 1.0f, -1.0f);
	glVertex3f(-1.0f, 1.0f, -1.0f);
	glVertex3f(-1.0f, 1.0f, 1.0f);
	glVertex3f(1.0f, 1.0f, 1.0f);

	// Bottom face (y = -1.0f)
	glColor3f(1.0f, 0.5f, 0.0f);     // Pomarańczowy
	glVertex3f(1.0f, -1.0f, 1.0f);
	glVertex3f(-1.0f, -1.0f, 1.0f);
	glVertex3f(-1.0f, -1.0f, -1.0f);
	glVertex3f(1.0f, -1.0f, -1.0f);

	// Front face  (z = 1.0f)
	glColor3f(1.0f, 0.0f, 0.0f);     // Czerwony
	glVertex3f(1.0f, 1.0f, 1.0f);
	glVertex3f(-1.0f, 1.0f, 1.0f);
	glVertex3f(-1.0f, -1.0f, 1.0f);
	glVertex3f(1.0f, -1.0f, 1.0f);

	// Back face (z = -1.0f)
	glColor3f(1.0f, 1.0f, 0.0f);     // Żółty
	glVertex3f(1.0f, -1.0f, -1.0f);
	glVertex3f(-1.0f, -1.0f, -1.0f);
	glVertex3f(-1.0f, 1.0f, -1.0f);
	glVertex3f(1.0f, 1.0f, -1.0f);

	// Left face (x = -1.0f)
	glColor3f(0.0f, 0.0f, 1.0f);     // Niebieski
	glVertex3f(-1.0f, 1.0f, 1.0f);
	glVertex3f(-1.0f, 1.0f, -1.0f);
	glVertex3f(-1.0f, -1.0f, -1.0f);
	glVertex3f(-1.0f, -1.0f, 1.0f);

	// Right face (x = 1.0f)
	glColor3f(1.0f, 0.0f, 1.0f);     // Fioletowy
	glVertex3f(1.0f, 1.0f, -1.0f);
	glVertex3f(1.0f, 1.0f, 1.0f);
	glVertex3f(1.0f, -1.0f, 1.0f);
	glVertex3f(1.0f, -1.0f, -1.0f);
	glEnd();  // Koniec rysowania kolorowego sześcianu
	
	switch (rFlag)
	{
	case 1:
		
		if (x < 2)x += 0.1; break;
	case 2:

		if (x >-2)x -= 0.1; break;
	case 3:

		if (y < 2)y += 0.1; break;
	case 4:

		if (y > -2)y -= 0.1; break;
	case 5:

		if (z < -2)z += 0.1; break;
	case 6:

		if (z > -20)z -= 0.1; break;
	case 7:break;
	case 8:
		xrot == 360 ? xrot = 0 : xrot += 5;
	
	
		
		break;
	case 9:
		xrot == 0 ? xrot = 360:	xrot -= 5;
		
		 break;
	case 10:
		yrot == 360 ? yrot = 0 : yrot += 5;
		break;
	case 11:
		yrot == 0 ? yrot = 360 : yrot -= 5;

		break;
	case 12:
		zrot == 360 ? zrot = 0 : zrot += 5;
		 break;
	case 13:
		zrot == 0 ? zrot = 360 : zrot -= 5;
		
		 break;
		
	default:
		break;
	}
	glTranslatef(0, 0, 0);
	glRotatef(xrot, 1.0f, 0, 0);
	glRotatef(yrot, 0, 1.0f, 0);
	glRotatef(zrot, 0, 0, 1.0f); 
	glTranslatef(x, y,z);
	
	glutSwapBuffers();  // Zamiana bufora przedniego i tylnego (podwójne buforowanie)
}


void reshape(GLsizei width, GLsizei height) {  // GLsizei liczba całkowita nieujemna
	// przeliczenia aspektu okna
	if (height == 0) height = 1;                // zapobieganie dzieleniu przez 0
	GLfloat aspect = (GLfloat)width / (GLfloat)height;

	// Ustalenie rzutni (viewport) obejmującej okno 
	glViewport(0, 0, width, height);

	// Ustawienie proporcji obrazu, aby pasowały do ​​widocznego obszaru rzutni
	glMatrixMode(GL_PROJECTION);  // Operowanie na macierzy projekcji
	glLoadIdentity();             // Resetowanie macierzy
	// Włączanie perspektywy projekcji z określonym aspektem 
	gluPerspective(45.0f, aspect, 0.1f, 100.0f);
}
void rotateMenu(int option)
{
	rFlag = option;
}


int main(int argc, char** argv) {
	glutInit(&argc, argv);            // Inicjalizacja biblioteki GLUT
	glutInitDisplayMode(GLUT_DOUBLE); // Włączenie podwójnego buforowania
	glutInitWindowSize(640, 480);   // Ustalenie rozmiarów okna
	glutInitWindowPosition(50, 50); // Ustalenie pozycji początkowej okna
	glutCreateWindow("z palca");          // Podanie tyłu okna
	glutDisplayFunc(display);       // Zarejestrowanie funkcji odświeżania ekranu (repaint)
	glutCreateMenu(rotateMenu);
	glutAddMenuEntry("prawo", 1);
	glutAddMenuEntry("lewo", 2);
	glutAddMenuEntry("gora", 3);
	glutAddMenuEntry("dol", 4);
	glutAddMenuEntry("przod",5);
	glutAddMenuEntry("tyl", 6);
	glutAddMenuEntry("obr prawo", 8);
	glutAddMenuEntry("obr lewo", 9);
	glutAddMenuEntry("obr gora", 10);
	glutAddMenuEntry("obr dol", 11);
	glutAddMenuEntry("obr przod", 12);
	glutAddMenuEntry("obr tyl", 13);
	glutAddMenuEntry("stop", 7);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	Timer(0);
	glutReshapeFunc(reshape);       // Zarejestrowanie funkcji obsługującej zmianę rozmiaru okna
	initGL();                       // Własna inicjalizacja OpenGL
	glutMainLoop();                 // Pętla nieskończona biblioteki OpenGL
	return 0;
}