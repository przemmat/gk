//#include <iostream>
//#include <GL/glut.h>
//using namespace std;
//
//
//double dx = 0;
//double dy = 0;
//double x1 = 0, x2 = 0, yy1 = 0, y2 = 0, x = 0, y = 0, i = 0;
//double step = 0;
//
//void glInit()
//{
//	
//	glClearColor(0.5, 0.0, 0.5, 1.0);
//	glClear(GL_COLOR_BUFFER_BIT);
//	glMatrixMode(GL_PROJECTION);
//	gluOrtho2D(0, 300, 0, 300);
//}
//
//void setPixel(int x, int y)
//{
//	glBegin(GL_POINTS);
//	glVertex2i(x, y);
//	glEnd();
//}
//
//void myDisplay()
//{
//	int dx, dy, kx, ky, e;
//	x1 <= x2 ? kx = 1 : kx = -1;
//	yy1 <= y2 ? ky = 1 : ky = -1;
//	dx = abs(x2 - x1);
//	dy = abs(y2 - yy1);
//	setPixel(x1, yy1);
//	if (dy < dx)
//	{
//		e = dx / 2;
//		for (int i = 0; i < dx; i++)
//		{
//			x1 = x1 + kx;
//			e = e - dy;
//			if (e < 0)
//			{
//				yy1 = yy1 + ky;
//				e = e + dx;
//			}
//			setPixel(x1, yy1);
//		}
//	}
//	else {
//		e = dy / 2;
//		for (int i = 0; i < dy; i++)
//		{
//			yy1 = yy1 + ky;
//			e = e - dx;
//			if (e < 0)
//			{
//				x1 = x1 + kx;
//				e = e + dy;
//			}
//			setPixel(x1, yy1);
//		}
//	}
//	glFlush();
//}
//
//int main(int argcp, char** argv)
//{
//
//	x1 = 100;
//	x2 = 200;
//	yy1 = 200;
//	y2 = 100;
//	glutInit(&argcp, argv);
//	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
//	glutInitWindowSize(300, 300);
//	glutInitWindowPosition(0, 0);
//	glutCreateWindow("Test OpenGL");
//	glInit();
//	glutDisplayFunc(myDisplay);
//	glutMainLoop();
//	return 0;
//
//
//}
////#include <iostream>
////#include <GL/glut.h>
////using namespace std;
////
////
////int dx = 0;
////int dy = 0;
////int x1 = 0, x2 = 0, yy1 = 0, y2 = 0, x = 0, y = 0, i = 0;
////int step = 0;
////
////void glInit()
////{
////	glClear(GL_COLOR_BUFFER_BIT);
////	glClearColor(0.0, 0.0, 0.0, 1.0);
////	glMatrixMode(GL_PROJECTION);
////	gluOrtho2D(0, 300, 0, 300);
////}
////
////void setPixel(int x, int y)
////{
////	glBegin(GL_POINTS);
////	glVertex2i(x, y);
////	glEnd();
////}
////
////void myDisplay()
////{
////
////	dx = abs(x2 - x1);
////	dy = abs(y2 - yy1);
////
////	if (abs(dx) >= abs(dy))
////	{
////		step = dx;
////	}
////	else
////	{
////		step = dy;
////	}
////	dx = dx / step;
////	dy = dy / step;
////	x = x1 + 0.5;
////	y = yy1 + 0.5;
////	i = 0;
////	while (i <= step)
////	{
////		setPixel(x, y);
////		x = x + dx;
////		y = y + dy;
////		i++;
////	}
////	glFlush();
////
////}
////
////int main(int argcp, char** argv)
////{
////
////	x1 = 100;
////	x2 = 50;
////	yy1 = 100;
////	y2 = 50;
////	glutInit(&argcp, argv);
////	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
////	glutInitWindowSize(300, 300);
////	glutInitWindowPosition(0, 0);
////	glutCreateWindow("Test OpenGL");
////	glInit();
////	glutDisplayFunc(myDisplay);
////	glutMainLoop();
////	return 0;
////
////
////}
